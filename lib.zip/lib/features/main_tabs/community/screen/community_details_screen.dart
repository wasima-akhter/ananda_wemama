import 'package:mama_app/core/components/ui/dialogs/popups.dart';
import 'package:mama_app/core/components/ui/feedback/ui_state/ui_state_card.dart';
import 'package:mama_app/core/components/ui/loaders/empty_widget.dart';
import 'package:mama_app/features/main_tabs/community/controller/community_detail_controller.dart';
import 'package:mama_app/features/main_tabs/community/model/community_item_detail_model.dart';
import 'package:mama_app/features/main_tabs/community/widgets/post_item_widget.dart';

import '../../../../app/helper_widgets_export.dart';
import '../../../../core/components/ui/loaders/shimmer_widget.dart';
import '../../../../core/models/ui/common_data_models.dart';
import '../modules/join_btn.dart';

class CommunityDetailsScreen extends StatelessWidget {
  const CommunityDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cdc = Get.find<CommunityDetailController>();
    final refreshKey = GlobalKey<RefreshIndicatorState>();

    return AppScreenTemplate(
      refreshKey: refreshKey,
      onRefresh: () async {
        log("communities refreshed");
        cdc.getCommunityDetail();
      },

      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Header with overlaid topbar ──
          Obx(() {
            final isLoading = cdc.isLoading_.value;
            final itemDetail = cdc.communityItemDetail.value;

            final state = getUIStateDetail(isLoading: isLoading);

            log('itemDetail  : ${itemDetail.community?.name} ');
            return Stack(
              children: [
                // ── Base content ──
                UIStateHandler(
                  onRefresh: () async {
                    cdc.getCommunityDetail();
                  },
                  state: state,
                  loading: () => Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ShimmerWidget.rectangular(
                        height: S.h * 0.25,
                        width: double.infinity,
                      ),
                      ContainerBordered(
                        rad: 0,
                        vp: 12,
                        hp: 0,
                        contClr: c.secondary,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ShimmerWidget.rectangular(height: 16, width: 150),
                            const Gap(8),
                            ShimmerWidget.rectangular(height: 12, width: 100),
                          ],
                        ).get10cm,
                      ),
                    ],
                  ),

                  data: () => CommunityDetailTopContent(
                    itemDetail: itemDetail,
                    cdc: cdc,
                  ),
                ),

                // your real header

                // ── Topbar overlaid on top of image ──
                Positioned(
                  top: itemGap,
                  right: 0,
                  left: 0,
                  child: CommunityTopbarContent(
                    suffix: (cdc.btnState.value == MyCommunityBtnState.join)
                        ? CusGestureDetector(
                            onTap: () {
                              if (cdc.btnState.value ==
                                  MyCommunityBtnState.manage) {
                                // edit the community
                                // communityGuidlineDialog(isLoading: false, onTapAction: () async {});

                                // Get.toNamed(
                                //   RoutePaths.manageCommunity,
                                //   arguments: CreateCommunityArgModel(
                                //     communityImg: itemDetail.community?.image ?? '',
                                //     communityName: itemDetail.community?.name ?? '',
                                //     communityId: itemDetail.community?.id ?? '',
                                //     isEdit: true,
                                //   ),
                                // );
                              }
                              if (cdc.btnState.value ==
                                  MyCommunityBtnState.visit) {}
                              if (cdc.btnState.value ==
                                  MyCommunityBtnState.join) {
                                communityGuidlineDialog(
                                  isLoading: false,
                                  onTapAction: () async {},
                                );
                              }
                            },
                            child: CusCircleIconButton(
                              radius: 15.r,
                              child: SvgIcon(
                                iconPath: IconsPath.info,
                                height: 30,
                              ),
                            ),
                          )
                        : const SizedBox.shrink(),
                  ),
                ),
              ],
            );
          }),

          Gap(itemGap * 2),

          // ── Posts ──
          Obx(() {
            final isLoading = cdc.isLoading_.value;
            final itemDetail = cdc.communityItemDetail.value;
            final itemPosts = itemDetail.allPost ?? [];
            final communityData = itemDetail.community ?? Community();

            final state = getUIStateList(isLoading: isLoading, list: itemPosts);

            log('itemDetail  : ${itemDetail.community?.name} ');

            return UIStateHandler(
              onRefresh: () async {
                cdc.getCommunityDetail();
              },
              state: state,
              loading: () => Column(
                children: List.generate(
                  5,
                  (index) => const PostItemShimmer().mB(itemGap),
                ),
              ).getcm,
              empty: () => const EmptyNoSearchWidget(title: "No Posts yet"),

              data: () => Column(
                children: List.generate(
                  itemPosts.length,
                  (index) =>
                      // Text("data")
                      PostItemWidget(
                        communityData: communityData,
                        postItem: itemPosts[index],
                        cc: cdc,
                        btnState: cdc.btnState.value,
                        postId: itemPosts[index].id.toString(),
                        userName: itemPosts[index].creator?.name ?? '',
                        postCreatorId: itemDetail.community?.id ?? '',
                      ).mB(itemGap),
                ),
              ).getcm,
            );
          }),

          Gap(itemGap * 2),
        ],
      ),
    );
  }
}

class CommunityDetailTopContent extends StatelessWidget {
  final CommunityItemDetailModel itemDetail;

  final CommunityDetailController cdc;

  const CommunityDetailTopContent({
    super.key,
    required this.itemDetail,
    required this.cdc,
  });

  @override
  Widget build(BuildContext context) {
    final community = itemDetail.community;
    final communityName = community?.name ?? '';
    final membersNum = (community?.totalMember ?? 0).toString();
    final communityImg = community?.image ?? '';

    log('membersNum  : $membersNum');
    log('community?.totalMember  : ${community?.totalMember}');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        NetworkImageWidget(
          imageUrl: communityImg,
          width: double.infinity,
          height: S.h * 0.25,
          radius: 0,
          isUser: false,
          enablePreview: true,
        ),
        ContainerBordered(
          rad: 0,
          vp: 12,
          hp: 0,
          contClr: c.secondary,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          // width: S.w * 0.75,
                          child: TextFit(
                            communityName.capEachWord(),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 7,
                            style: TxtStyle.outfitSemiB(
                              fs: 18,
                              w: 500,
                              color: white,
                            ),
                          ),
                        ),
                        Row(
                          children: [
                            SvgIcon(iconPath: IconsPath.userGroup, height: 22),
                            Gap(4),
                            TextFit(
                              "${Strings.members.capEachWord()} $membersNum",
                              style: TxtStyle.outfit(
                                fs: 12,
                                w: 400,
                                color: white,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  Gap(itemGap),

                  // wrap JoinBtn with Obx
                  Obx(() {
                    return JoinBtn(
                      isLoading: cdc.isJoinLoading.value,
                      btnTxt: cdc.getBtnTxt(), // now reactive
                      onTap: () {
                        if (cdc.btnState.value == MyCommunityBtnState.manage) {
                          Get.toNamed(
                            RoutePaths.manageCommunity,
                            arguments: CreateCommunityArgModel(
                              communityImg: itemDetail.community?.image ?? '',
                              communityName: itemDetail.community?.name ?? '',
                              communityId: itemDetail.community?.id ?? '',
                              isEdit: true,
                            ),
                          );
                        }

                        if (cdc.btnState.value == MyCommunityBtnState.join) {
                          communityGuidlineDialog(
                            isLoading: cdc.isJoinLoading.value,
                            onTapAction: () async {
                              Get.back();

                              final success = await cdc.joinCommunity(
                                communityItemId: itemDetail.community?.id ?? '',
                              );

                              if (success) {
                                Get.toNamed(
                                  RoutePaths.communityDetail,
                                  arguments: {
                                    "btnState": MyCommunityBtnState.visit,
                                    "communityItemId":
                                        itemDetail.community?.id ?? '',
                                  },
                                );
                              }
                            },
                          );
                        }
                      },
                    );
                  }),
                ],
              ),
              Gap(itemGap * 3),

              CusGestureDetector(
                onTap: () {
                  Get.toNamed(
                    RoutePaths.postInCommunity,
                    arguments: community?.id ?? '',
                  );
                },
                child: ContainerBordered(
                  rad: 30,
                  contClr: bgClr,
                  vp: 10,
                  hp: 14,
                  alignment: Alignment.centerLeft,
                  child: Text(
                    Strings.writeSomething.capEachWord(),
                    style: TxtStyle.outfit(color: c.secondary, fs: 12),
                  ),
                ),
              ),

              //   CusNameTypeTextFormField(
              //   controller: cdc.postCtrl,
              //   hintText: Strings.writeSomething,
              // ),
            ],
          ).get10cm,
        ),
      ],
    );
  }
}

//
