import 'package:mama_app/app/helper_widgets_export.dart';

import '../../../../gen/assets.gen.dart';

class CircleImage extends StatelessWidget {
  final double? radius;
  const CircleImage({Key? key, this.radius}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: (radius ?? 20).r,
      backgroundImage: Assets.images.profileDemoPic1.image().image,
    );
  }
}

class IconInCircleBrdr extends StatelessWidget {
  final String iconPath;
  final String goToPath;
  final double? radius;
  const IconInCircleBrdr({super.key, required this.iconPath, required this.goToPath, this.radius});

  @override
  Widget build(BuildContext context) {
    return CusGestureDetector(
      onTap: () {
        GNav.pushNamed(goToPath);
      },
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: c.secondary),
          color: c.inputBackground,
        ),
        child: CircleAvatar(
          radius: radius ?? 17.r,
          backgroundColor: c.inputBackground,
          child: SvgIcon(iconPath: iconPath),
        ),
      ),
    );
  }
}
