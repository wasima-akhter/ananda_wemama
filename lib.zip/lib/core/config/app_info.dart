// Application information and configuration constants

const String baseUrl = "https://api.wemama.app";
// const String baseUrl = "https://k85v0kkf-8005.inc1.devtunnels.ms";

const String appName = "We Mama";

const String appVersion = "1.0.0";
const String buildNumber = "1";

const String routeInitial = '/';
