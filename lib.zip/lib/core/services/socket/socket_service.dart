import 'dart:async';

import 'package:mama_app/core/config/app_info.dart';
import 'package:mama_app/core/services/socket/socket_listener_registry.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

import '../../../app/service_export.dart';
import 'socket_events.dart';
import 'socket_status_controller.dart';

class SocketService extends GetxService {
  IO.Socket? _socket;

  Completer<void>? _connectCompleter;

  bool get isConnected => _socket?.connected ?? false;

  // ── onInit: nothing socket-related here — socket doesn't exist yet ─────────

  // ═══════════════════════════════════════════════════════════════════════════
  // CONNECT
  // ═══════════════════════════════════════════════════════════════════════════

  void _removeAllListeners() {
    final events = [
      SocketEvents.sendConversationRequest,
      SocketEvents.newConversationRequest,
      SocketEvents.newNotification,
      SocketEvents.conversationRequests,
      SocketEvents.conversationAccepted,
      SocketEvents.conversationRejected,
      SocketEvents.chatList,
      SocketEvents.messages,
      SocketEvents.newMessage,
    ];
    _socket!.off(SocketEvents.chatList);
    _socket!.off(SocketEvents.messages);
    _socket!.off(SocketEvents.newMessage);
    _socket!.off(SocketEvents.newNotification);
    _socket!.off(SocketEvents.newConversationRequest);
    _socket!.off(SocketEvents.sendConversationRequest);
    _socket!.off(SocketEvents.conversationRequests);
    _socket!.off(SocketEvents.conversationAccepted);
    _socket!.off(SocketEvents.conversationRejected);

    for (final event in events) {
      _socket?.off(event);
    }
  }

  Future<void> connectSocket() async {
    _connectCompleter = Completer<void>();

    try {
      if (_socket != null) {
        _removeAllListeners();
        _socket?.clearListeners();
        _socket?.disconnect();
        _socket?.dispose();
        _socket?.destroy();
        _socket = null;
      }

      _socket = IO.io(
        baseUrl,
        IO.OptionBuilder()
            .setTransports(['websocket'])
            .setAuth({'token': getToken}) // ✅ picks up NEW user's token
            .disableAutoConnect()
            .enableForceNew()
            .build(),
      );

      _socket!.onConnect((_) {
        log("✅ Socket Connected: ${_socket!.id}");
        if (!(_connectCompleter?.isCompleted ?? true)) {
          _connectCompleter?.complete();
        }
      });

      _socket!.onConnectError((err) {
        log("❌ Socket error: $err");
        if (!(_connectCompleter?.isCompleted ?? true)) {
          _connectCompleter?.completeError(err);
        }
      });

      _registerListeners(); // registers fresh on the new socket instance

      _socket!.connect();

      return _connectCompleter!.future;
    } catch (e) {
      log("Socket connect crashed: $e");
      if (!(_connectCompleter?.isCompleted ?? true)) {
        _connectCompleter?.complete();
      }
    }
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // LISTENERS — registered once per connectSocket() call
  // ═══════════════════════════════════════════════════════════════════════════

  void _registerListeners() {
    //
    //
    _registerRetryListeners(); //

    // ---- here was the onn anf off event listeners

    if (_socket != null) {
      SocketListenerRegistry(_socket!).registerAll();
    }

    ////
    ///
    ///
    ///
    //
    //
    // ```

    // ---

    // **The flow now:**
    // ```
    // User taps Accept
    //   → onTapAction() stores _pendingConversationId, emits socket
    //     → Socket fires conversation_accepted
    //       → SocketService sets wrc.isSuccessAccept = true
    //         → ever() triggers _onAcceptSuccess()
    //           → removes from list + shows dialogs ✅

    // User taps Reject
    //   → onTapAction() stores _pendingConversationId, emits socket
    //     → Socket fires conversation_rejected
    //       → SocketService sets wrc.isSuccessReject = true
    //         → ever() triggers _onRejectSuccess()
    //           → removes from list silently ✅
    //   //
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EMIT
  // ═══════════════════════════════════════════════════════════════════════════

  void emit(String event, dynamic data) {
    log("token now: $getToken");
    if (!isConnected) {
      log("⚠️ Emit skipped — socket not connected → $event");
      return;
    }
    _socket!.emit(event, data);
    log("📤 Emit: $event → $data");
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LISTENER WRAPPERS
  // ═══════════════════════════════════════════════════════════════════════════

  /// Internal — always called after _socket is assigned.
  void _on(String event, Function(Map<String, dynamic>) callback) {
    _socket!.on(event, (data) {
      try {
        callback(_parse(data));
        log("📥 Listen: [$event] $data");
      } catch (e, stack) {
        log("❌ Callback error [$event]: $e\n$stack");
      }
    });
  }

  /// Public — for one-off listeners added externally (e.g. from a controller).
  /// Only safe to call after connectSocket().
  void on(String event, Function(Map<String, dynamic>) callback) {
    if (_socket == null) {
      log("⚠️ on('$event') — socket not ready, call connectSocket() first");
      return;
    }
    _on(event, callback);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // CLEANUP
  // ═══════════════════════════════════════════════════════════════════════════

  void off(String event) {
    _socket?.off(event);
    log("🧹 Removed listener: $event");
  }

  @override
  void onClose() {
    _retryTimer?.cancel();
    _onConnectedController.close(); // ✅ missing
    _socket?.clearListeners();
    _socket?.disconnect();
    _socket?.destroy();
    _socket = null;
    super.onClose();
  }

  void disconnectSocket() {
    _retryTimer?.cancel();
    _retryTimer = null;
    _retryCount = 0; // ✅ reset so retry logic starts clean for new user
    _socket?.clearListeners();
    _socket?.disconnect();
    _socket?.destroy();
    _socket = null; // ✅ critical — forces full rebuild on next connect
    log("🔴 Socket manually disconnected");
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // PARSER
  // ═══════════════════════════════════════════════════════════════════════════

  Map<String, dynamic> _parse(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    return Map<String, dynamic>.from(data as Map);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // AUTO-RETRY — added without touching any existing logic
  // ═══════════════════════════════════════════════════════════════════════════

  static const int _maxRetries = 8;
  static const Duration _baseDelay = Duration(seconds: 2);

  int _retryCount = 0;
  Timer? _retryTimer;
  // ✅ Add this — single source of truth for socket readiness
  final _onConnectedController = StreamController<void>.broadcast();
  Stream<void> get onConnected => _onConnectedController.stream;

  /// Called once inside _registerListeners() — hooks into socket lifecycle.
  // At the top of _registerRetryListeners()
  void _registerRetryListeners() {
    _socket!.onConnect((_) {
      _retryCount = 0;
      _retryTimer?.cancel();
      _retryTimer = null;
      log("🔁 Retry state reset — socket healthy");
      log("✅ Socket Connected: ${_socket!.id}");

      if (!(_connectCompleter?.isCompleted ?? true)) {
        _connectCompleter?.complete();
      }

      // ✅ Broadcast to all listeners
      _onConnectedController.add(null);

      // ✅ NEW
      if (Get.isRegistered<SocketStatusController>()) {
        SocketStatusController.to.setConnected();
      }
    });

    _socket!.onDisconnect((reason) {
      log("🔌 Disconnected — reason: $reason");
      log("🔌 Socket disconnected — scheduling retry...");

      _scheduleRetry();
    });

    _socket!.onConnectError((_) {
      log("❌ Connect error — scheduling retry...");
      _scheduleRetry();
    });
  }

  void _scheduleRetry() {
    _retryTimer?.cancel();

    if (_retryCount >= _maxRetries) {
      log("🚫 Max retries ($_maxRetries) reached. Giving up.");

      // ✅ NEW
      if (Get.isRegistered<SocketStatusController>()) {
        SocketStatusController.to.setFailed();
      }
      return;
    }

    final delay = Duration(
      seconds: (_baseDelay.inSeconds * (1 << _retryCount)).clamp(2, 60),
    );

    _retryCount++;

    // ✅ NEW
    if (Get.isRegistered<SocketStatusController>()) {
      SocketStatusController.to.setReconnecting(_retryCount);
    }

    log("⏳ Retry #$_retryCount in ${delay.inSeconds}s...");

    _retryTimer = Timer(delay, () async {
      if (!isConnected) {
        log("🔄 Attempting reconnect #$_retryCount...");
        try {
          // ✅ Reuse existing socket if still alive
          // if (_socket != null) {
          //   _socket!.connect(); // just reconnect, no listener rebuild
          // }
          if (_socket != null) {
            _socket!.io.options?['auth'] = {'token': getToken};

            log("🔐 Reconnect token: $getToken");

            _socket!.connect();
          } else {
            await connectSocket(); // full rebuild only if socket was destroyed
          }
        } catch (e) {
          log("❌ Reconnect #$_retryCount failed: $e");
        }
      }
    });
  }
}

/*


{"statusCode":200,"success":true,"message":"You have retrieved all conversation requests.","data":[{"_id":"69c3b1238adbc682371dbea3","participants":[{"_id":"69ae9cb708dc2ab1a71ac76e","name":"soubir","profileImage":"uploads/profile-image/profile-avatar-1773811023684.jpeg"},{"_id":"69b661d6abc1103705aa7704","name":"abc","profileImage":"uploads/profile-image/screenshot-2026-03-17-094619-1773741134511.png"}],"status":"Pending","createdAt":"2026-03-25T09:55:47.826Z","updatedAt":"2026-03-25T09:55:47.826Z","__v":0}]}
*/
